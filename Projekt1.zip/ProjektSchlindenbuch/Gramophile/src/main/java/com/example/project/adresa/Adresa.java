package com.example.project.adresa;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "ADRESA")
public class Adresa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_adresa")
    private Long idAdresa;

    @Size(max = 50)
    @Column(name = "ulice", nullable = false)
    private String ulice;

    @Size(max = 50)
    @Column(name = "cislo_popisne", nullable = false)
    private String cisloPopisne;

    @Size(max = 50)
    @Column(name = "obec", nullable = false)
    private String obec;

    @Size(max = 10)
    @Column(name = "PSC", nullable = false)
    private String psc;

    public Adresa() {}

    public Adresa(Long idAdresa, String ulice, String cisloPopisne, String obec, String psc) {
        this.idAdresa = idAdresa;
        this.ulice = ulice;
        this.cisloPopisne = cisloPopisne;
        this.obec = obec;
        this.psc = psc;
    }

    public Long getIdAdresa() {return idAdresa;}
    public void setIdAdresa(Long idAdresa) {this.idAdresa = idAdresa;}
    public String getUlice() {return ulice;}
    public void setUlice(String ulice) {this.ulice = ulice;}
    public String getCisloPopisne() {return cisloPopisne;}
    public void setCisloPopisne(String cisloPopisne) {this.cisloPopisne = cisloPopisne;}
    public String getObec() {return obec;}
    public void setObec(String obec) {this.obec = obec;}
    public String getPsc() {return psc;}
    public void setPsc(String psc) {this.psc = psc;}
}