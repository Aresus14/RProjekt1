package com.example.project.adresa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/adresy")
public class AdresaController {

    @Autowired
    private AdresaService adresaService;

    @GetMapping
    public List<Adresa> getAllUsers() {
        return adresaService.findAllAdresa();
    }

    @GetMapping("/{id}")
    public Adresa getAdresaById(@PathVariable Long id) {
        return adresaService.findAdresaById(id);
    }

    @PostMapping
    public Adresa createAdresa(@Valid @RequestBody Adresa adresa) {
        System.out.println("Received adresa: " + adresa.getObec() + " " + adresa.getUlice() + " " + adresa.getCisloPopisne() + " " + adresa.getPsc());
        return adresaService.createAdresa(adresa);
    }

    @PutMapping("/{id}")
    public Adresa updateAdresa(@PathVariable Long id, @RequestBody Adresa adresa) {
        return adresaService.updateAdresa(id, adresa);
    }

    @DeleteMapping("/{id}")
    public void deleteAdresa(@PathVariable Long id) {
        adresaService.deleteAdresa(id);
    }
}