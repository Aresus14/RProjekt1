package com.example.project.adresa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AdresaRepository extends JpaRepository<Adresa, Long>{
}
