package com.example.project.adresa;

import com.example.project.adresa.Adresa;
import com.example.project.adresa.AdresaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class AdresaService {


    private final AdresaRepository adresaRepository;

    public AdresaService(AdresaRepository adresaRepository) {
        this.adresaRepository = adresaRepository;
    }

    public List<Adresa> findAllAdresa() {
        return adresaRepository.findAll();
    }

    public Adresa findAdresaById(Long id) {
        return adresaRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Adresa not found"));
    }

    public Adresa createAdresa(Adresa adresa) {
        return adresaRepository.save(adresa);
    }

    public Adresa updateAdresa(Long id, Adresa updatedAdresa) {
        Adresa adresa = findAdresaById(id);
        adresa.setUlice(updatedAdresa.getUlice());
        adresa.setCisloPopisne(updatedAdresa.getCisloPopisne());
        adresa.setObec(updatedAdresa.getObec());
        adresa.setPsc(updatedAdresa.getPsc());
        return adresaRepository.save(adresa);
    }

    public void deleteAdresa(Long id) {
        if (!adresaRepository.existsById(id)) {
            throw new NoSuchElementException("Adresa not found");
        }
        adresaRepository.deleteById(id);
    }
}
