package com.example.project.doprava;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

@Entity
@Table(name = "DOPRAVA")
public class Doprava {

    @Id
    @Column(name = "ID_doprava", unique = true)
    private Long idDoprava;

    @NotNull
    @Column(name = "nazev_dopravce", length = 50)
    private String nazevDopravce;

    @NotNull
    @Column(name = "cena", length = 20)
    private BigDecimal cena;

    public Doprava() {}

    public Doprava(Long idDoprava, String nazevDopravce, BigDecimal cena) {
        this.idDoprava = idDoprava;
        this.nazevDopravce = nazevDopravce;
        this.cena = cena;
    }

    public Long getIdDoprava() {return idDoprava;}
    public void setIdDoprava(Long idDoprava) {this.idDoprava = idDoprava;}
    public String getNazevDopravce() {return nazevDopravce;}
    public void setNazevDopravce(String nazevDopravce) {this.nazevDopravce = nazevDopravce;}
    public BigDecimal getCena() { return cena; }
    public void setCena(BigDecimal cena) { this.cena = cena; }
}