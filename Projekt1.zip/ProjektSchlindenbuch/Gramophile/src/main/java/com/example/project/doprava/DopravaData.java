package com.example.project.doprava;

import com.example.project.doprava.Doprava;
import com.example.project.doprava.DopravaRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DopravaData implements CommandLineRunner {

    private final DopravaRepository dopravaRepository;

    public DopravaData(DopravaRepository dopravaRepository) {
        this.dopravaRepository = dopravaRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (dopravaRepository.count() == 0) {
            dopravaRepository.save(new Doprava(1L, "ČESKÁ POŠTA", new BigDecimal("60")));
            dopravaRepository.save(new Doprava(2L, "ZÁSILKOVŇAČ",new BigDecimal("50")));
            dopravaRepository.save(new Doprava(3L, "POŠTIN", new BigDecimal("80")));
        }
    }
}