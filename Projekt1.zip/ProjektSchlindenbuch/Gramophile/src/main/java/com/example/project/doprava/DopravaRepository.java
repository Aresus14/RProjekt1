package com.example.project.doprava;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DopravaRepository extends JpaRepository<Doprava, Long>{
}
