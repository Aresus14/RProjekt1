package com.example.project.objednavka;

import com.example.project.adresa.Adresa;
import com.example.project.doprava.Doprava;
import com.example.project.platba.Platba;
import com.example.project.zakaznik.Zakaznik;
import com.example.project.objednavkatitul.ObjednavkaTitul;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "OBJEDNAVKA")
public class Objednavka {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_objednavka")
    private Long idObjednavka;

    @ManyToOne
    @JoinColumn(name = "PLATBA_ID_platba")  // bez insertable=false, updatable=false
    private Platba platba;


    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "ZAKAZNIK_ID_zakaznik")
    private Zakaznik zakaznik;

    @OneToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "ADRESA_ID_adresa")
    private Adresa adresa;



    @ManyToOne
    @JoinColumn(name = "DOPRAVA_ID_doprava")
    private Doprava doprava;

    @OneToMany(mappedBy = "objednavka", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ObjednavkaTitul> polozky = new ArrayList<>();

    @Column(name = "celkova_cena", length = 20)
    private BigDecimal celkovaCena;

    public Objednavka() {}

    // Gettery a settery

    public Long getIdObjednavka() { return idObjednavka; }
    public void setIdObjednavka(Long idObjednavka) { this.idObjednavka = idObjednavka; }

    public Platba getPlatba() { return platba; }
    public void setPlatba(Platba platba) { this.platba = platba; }

    public Zakaznik getZakaznik() { return zakaznik; }
    public void setZakaznik(Zakaznik zakaznik) { this.zakaznik = zakaznik; }

    public Adresa getAdresa() { return adresa; }
    public void setAdresa(Adresa adresa) { this.adresa = adresa; }

    public Doprava getDoprava() { return doprava; }
    public void setDoprava(Doprava doprava) { this.doprava = doprava; }

    public List<ObjednavkaTitul> getPolozky() { return polozky; }
    public void setPolozky(List<ObjednavkaTitul> polozky) { this.polozky = polozky; }

    public void setCelkovaCena(BigDecimal celkovaCena) { this.celkovaCena = celkovaCena; }

    public BigDecimal getCelkovaCena() {
        BigDecimal sumaTitulu = BigDecimal.ZERO;

        for (ObjednavkaTitul ot : polozky) {
            BigDecimal cenaTitulu = ot.getTitul().getCena(); // předpokládám BigDecimal
            BigDecimal mnozstvi = BigDecimal.valueOf(ot.getMnozstvi());
            sumaTitulu = sumaTitulu.add(cenaTitulu.multiply(mnozstvi));
        }

        BigDecimal cenaDopravy = (doprava != null) ? doprava.getCena() : BigDecimal.ZERO;

        return sumaTitulu.add(cenaDopravy);
    }
}