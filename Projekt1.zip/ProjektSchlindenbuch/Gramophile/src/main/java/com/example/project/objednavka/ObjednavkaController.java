package com.example.project.objednavka;

import com.example.project.adresa.Adresa;
import com.example.project.zakaznik.Zakaznik;
import com.example.project.zakaznik.ZakaznikService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.project.objednavka.ObjednavkaRepository;
import com.example.project.zakaznik.ZakaznikRepository;

import java.math.BigDecimal;
import java.util.Optional;

@RestController
@RequestMapping("/api/objednavky")
public class ObjednavkaController {

    private final ObjednavkaService objednavkaService;

    public ObjednavkaController(ObjednavkaService objednavkaService, ZakaznikService zakaznikService) {
        this.objednavkaService = objednavkaService;
    }

    @PostMapping
    public ResponseEntity<Objednavka> createEmptyOrder() {
        Objednavka novaObjednavka = objednavkaService.createEmptyOrder();
        return ResponseEntity.ok(novaObjednavka);
    }

    @PutMapping("/{id}/platba/{platbaId}")
    public ResponseEntity<Objednavka> nastavPlatbu(
            @PathVariable Long id,
            @PathVariable Long platbaId
    ) {
        Objednavka objednavka = objednavkaService.setPlatba(id, platbaId);
        return ResponseEntity.ok(objednavka);
    }

    @PutMapping("/{id}/doprava/{dopravaId}")
    public ResponseEntity<Objednavka> nastavDopravu(
            @PathVariable Long id,
            @PathVariable Long dopravaId
    ) {
        Objednavka objednavka = objednavkaService.setDoprava(id, dopravaId);
        return ResponseEntity.ok(objednavka);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Objednavka> getObjednavka(@PathVariable Long id) {
        Objednavka objednavka = objednavkaService.findById(id);
        if (objednavka == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(objednavka);
    }

    @PutMapping("/{id}/titul/{titulId}")
    public ResponseEntity<Objednavka> pridejTitulKObjednavce(
            @PathVariable Long id,
            @PathVariable Long titulId,
            @RequestParam(defaultValue = "1") int mnozstvi
    ) {
        Objednavka objednavka = objednavkaService.pridejTitul(id, titulId, mnozstvi);
        return ResponseEntity.ok(objednavka);
    }

    @GetMapping("/{id}/cena")
    public ResponseEntity<BigDecimal> getCenaObjednavky(@PathVariable Long id) {
        Objednavka objednavka = objednavkaService.findById(id);
        BigDecimal cena = objednavka.getCelkovaCena();
        return ResponseEntity.ok(cena);
    }

    @PutMapping("/{id}/adresa")
    public ResponseEntity<Objednavka> nastavAdresu(
            @PathVariable Long id,
            @RequestBody @Valid Adresa novaAdresa
    ) {
        Objednavka objednavka = objednavkaService.setAdresa(id, novaAdresa);
        return ResponseEntity.ok(objednavka);
    }

    @PutMapping("/{id}/zakaznik")
    public ResponseEntity<Objednavka> nastavZakaznika(
            @PathVariable Long id,
            @RequestBody @Valid Zakaznik novyZakaznik
    ) {
        Objednavka objednavka = objednavkaService.setZakaznik(id, novyZakaznik);
        return ResponseEntity.ok(objednavka);
    }

}


