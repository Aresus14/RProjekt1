package com.example.project.objednavka;


import com.example.project.adresa.Adresa;
import com.example.project.doprava.Doprava;
import com.example.project.objednavkatitul.ObjednavkaTitul;
import com.example.project.objednavkatitul.ObjednavkaTitulId;
import com.example.project.platba.Platba;
import com.example.project.platba.PlatbaRepository;
import com.example.project.titul.Titul;
import com.example.project.zakaznik.Zakaznik;
import com.example.project.zakaznik.ZakaznikRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.project.titul.TitulRepository;

import java.util.Optional;


@Service
public class ObjednavkaService {

    @Autowired
    private PlatbaRepository platbaRepository;
    @Autowired
    private ZakaznikRepository zakaznikRepository;
    @Autowired
    private TitulRepository titulRepository;

    private final ObjednavkaRepository objednavkaRepository;

    public ObjednavkaService(ObjednavkaRepository objednavkaRepository) {
        this.objednavkaRepository = objednavkaRepository;
    }

    public Objednavka findById(Long id) {
        Optional<Objednavka> objednavkaOpt = objednavkaRepository.findById(id);
        return objednavkaOpt.orElse(null);
    }

    public Objednavka createEmptyOrder() {
        Objednavka objednavka = new Objednavka();
        objednavka.setCelkovaCena(null);
        objednavka.setZakaznik(null);
        objednavka.setDoprava(null);
        objednavka.setPlatba(null);
        return objednavkaRepository.save(objednavka);
    }

    public Objednavka setPlatba(Long objednavkaId, Long platbaId) {
        Objednavka objednavka = objednavkaRepository.findById(objednavkaId)
                .orElseThrow(() -> new RuntimeException("Objednávka nenalezena"));
        Platba platba = new Platba(); // nebo platbaRepository.findById(platbaId) pokud máš repository
        platba.setIdPlatba(platbaId);
        objednavka.setPlatba(platba);
        return objednavkaRepository.save(objednavka);
    }

    public Objednavka setDoprava(Long objednavkaId, Long dopravaId) {
        Objednavka objednavka = objednavkaRepository.findById(objednavkaId)
                .orElseThrow(() -> new RuntimeException("Objednávka nenalezena"));
        Doprava doprava = new Doprava(); // nebo dopravaRepository.findById(dopravaId) pokud máš repository
        doprava.setIdDoprava(dopravaId);
        objednavka.setDoprava(doprava);
        return objednavkaRepository.save(objednavka);
    }

    public Objednavka pridejTitul(Long objednavkaId, Long titulId, int mnozstvi) {
        Objednavka objednavka = objednavkaRepository.findById(objednavkaId)
                .orElseThrow(() -> new RuntimeException("Objednávka nenalezena"));

        // Zkus najít existující položku
        Optional<ObjednavkaTitul> existujici = objednavka.getPolozky().stream()
                .filter(ot -> ot.getTitul().getIdTitul().equals(titulId))
                .findFirst();

        if (existujici.isPresent()) {
            // Přičti množství
            ObjednavkaTitul polozka = existujici.get();
            polozka.setMnozstvi(polozka.getMnozstvi() + mnozstvi);
        } else {
            // Vytvoř novou položku
            Titul titul = new Titul();
            titul.setIdTitul(titulId);

            ObjednavkaTitul ot = new ObjednavkaTitul();
            ot.setObjednavka(objednavka);
            ot.setTitul(titul);
            ot.setMnozstvi(mnozstvi);

            ObjednavkaTitulId otId = new ObjednavkaTitulId();
            otId.setObjednavkaId(objednavkaId);
            otId.setTitulId(titulId);
            ot.setId(otId);

            objednavka.getPolozky().add(ot);
        }

        return objednavkaRepository.save(objednavka);
    }

    public Objednavka setAdresa(Long objednavkaId, Adresa novaAdresa) {
        Objednavka objednavka = objednavkaRepository.findById(objednavkaId)
                .orElseThrow(() -> new RuntimeException("Objednávka nenalezena"));

        objednavka.setAdresa(novaAdresa); // Adresa bude automaticky uložena díky CascadeType.PERSIST
        return objednavkaRepository.save(objednavka);
    }






    public Objednavka setZakaznik(Long objednavkaId, Zakaznik novyZakaznik) {
        Objednavka objednavka = objednavkaRepository.findById(objednavkaId)
                .orElseThrow(() -> new RuntimeException("Objednávka nenalezena"));

        objednavka.setZakaznik(novyZakaznik); // Zakaznik bude uložen díky CascadeType.PERSIST
        return objednavkaRepository.save(objednavka);
    }
}