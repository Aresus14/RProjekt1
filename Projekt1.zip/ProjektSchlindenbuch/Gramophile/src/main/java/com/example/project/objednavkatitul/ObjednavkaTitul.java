package com.example.project.objednavkatitul;

import com.example.project.objednavka.Objednavka;
import com.example.project.titul.Titul;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "OBJEDNAVKA_TITUL")
public class ObjednavkaTitul implements Serializable {

    @EmbeddedId
    private ObjednavkaTitulId id = new ObjednavkaTitulId();

    @ManyToOne
    @MapsId("objednavkaId")
    @JoinColumn(name = "OBJEDNAVKA_ID_objednavka")
    @JsonIgnore
    private Objednavka objednavka;

    @ManyToOne
    @MapsId("titulId")
    @JoinColumn(name = "TITUL_ID_titul")
    private Titul titul;

    @Column(name = "mnozstvi")
    private int mnozstvi;


    public ObjednavkaTitul() {}

    public ObjednavkaTitul(Objednavka objednavka, Titul titul, int mnozstvi) {
        this.objednavka = objednavka;
        this.titul = titul;
        this.mnozstvi = mnozstvi;
        this.id = new ObjednavkaTitulId(objednavka.getIdObjednavka(), titul.getIdTitul());
    }

    // gettery a settery
    public ObjednavkaTitulId getId() { return id; }
    public void setId(ObjednavkaTitulId id) { this.id = id; }

    public Objednavka getObjednavka() { return objednavka; }
    public void setObjednavka(Objednavka objednavka) { this.objednavka = objednavka; }

    public Titul getTitul() { return titul; }
    public void setTitul(Titul titul) { this.titul = titul; }

    public int getMnozstvi() { return mnozstvi; }
    public void setMnozstvi(int mnozstvi) { this.mnozstvi = mnozstvi; }
}