package com.example.project.objednavkatitul;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class ObjednavkaTitulId implements Serializable {

    @Column(name = "OBJEDNAVKA_ID_objednavka")
    private Long objednavkaId;

    @Column(name = "TITUL_ID_titul")
    private Long titulId;

    public ObjednavkaTitulId() {}

    public ObjednavkaTitulId(Long objednavkaId, Long titulId) {
        this.objednavkaId = objednavkaId;
        this.titulId = titulId;
    }

    public Long getObjednavkaId() {
        return objednavkaId;
    }

    public void setObjednavkaId(Long objednavkaId) {
        this.objednavkaId = objednavkaId;
    }

    public Long getTitulId() {
        return titulId;
    }

    public void setTitulId(Long titulId) {
        this.titulId = titulId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ObjednavkaTitulId that)) return false;
        return Objects.equals(objednavkaId, that.objednavkaId) &&
                Objects.equals(titulId, that.titulId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(objednavkaId, titulId);
    }
}
