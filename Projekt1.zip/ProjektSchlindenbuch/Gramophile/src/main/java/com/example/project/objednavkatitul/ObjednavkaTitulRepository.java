package com.example.project.objednavkatitul;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ObjednavkaTitulRepository extends JpaRepository<ObjednavkaTitul, Long>{
}
