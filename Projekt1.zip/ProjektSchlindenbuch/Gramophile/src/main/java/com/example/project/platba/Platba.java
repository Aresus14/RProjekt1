package com.example.project.platba;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "PLATBA")
public class Platba {

    @Id
    @Column(name = "ID_platba")
    private Long idPlatba;

    @NotNull
    @Column(name = "zpusob_platby", length = 50)
    private String zpusobPlatby;

    public Platba() {}

    public Platba(Long idPlatba, String zpusobPlatby) {
        this.idPlatba = idPlatba;
        this.zpusobPlatby = zpusobPlatby;
    }

    public Long getIdPlatba() {return idPlatba;}
    public void setIdPlatba(Long idPlatba) {this.idPlatba = idPlatba;}
    public String getZpusobPlatby() {return zpusobPlatby;}
    public void setZpusobPlatby(String zpusobPlatby) {this.zpusobPlatby = zpusobPlatby;}
}
