package com.example.project.platba;

import com.example.project.platba.Platba;
import com.example.project.platba.PlatbaRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class PlatbaData implements CommandLineRunner {

    private final PlatbaRepository platbaRepository;

    public PlatbaData(PlatbaRepository platbaRepository) {
        this.platbaRepository = platbaRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (platbaRepository.count() == 0) {
            platbaRepository.save(new Platba(1L, "Kartou"));
            platbaRepository.save(new Platba(2L, "Dobírkou"));
            platbaRepository.save(new Platba(3L, "Přes účet"));
        }
    }
}