package com.example.project.platba;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PlatbaRepository extends JpaRepository<Platba, Long>{
}
