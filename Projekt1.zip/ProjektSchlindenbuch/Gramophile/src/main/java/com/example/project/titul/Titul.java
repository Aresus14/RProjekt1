package com.example.project.titul;

import com.example.project.objednavkatitul.ObjednavkaTitul;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.List;
import java.util.ArrayList;


@Entity
@Table(name = "TITUL")
public class Titul {

    @Id
    @Column(name = "ID_titul")
    private Long idTitul;

    @Column(name = "nazev", length = 50, nullable = false)
    @NotNull
    private String nazev;

    @Column(name = "cena", length = 20, nullable = false)
    @NotNull
    private BigDecimal cena;

    @OneToMany(mappedBy = "titul", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<ObjednavkaTitul> objednavky = new ArrayList<>();

    public Titul() {}

    public Titul(Long idTitul, String nazev, BigDecimal cena) {
        this.idTitul = idTitul;
        this.nazev = nazev;
        this.cena = cena;
    }

    public Long getIdTitul() { return idTitul; }
    public void setIdTitul(Long idTitul) { this.idTitul = idTitul; }
    public String getNazev() { return nazev; }
    public void setNazev(String nazev) { this.nazev = nazev; }

    public BigDecimal getCena() { return cena; }
    public void setCena(BigDecimal cena) { this.cena = cena; }
}