package com.example.project.titul;

import com.example.project.titul.Titul;
import com.example.project.titul.TitulRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class TitulData implements CommandLineRunner {

    private final TitulRepository titulRepository;

    public TitulData(TitulRepository titulRepository) {
        this.titulRepository = titulRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (titulRepository.count() == 0) {
            titulRepository.save(new Titul(1L, "NINE INCH NAILS - PRETTY HATE MACHINE", new BigDecimal("1100")));
            titulRepository.save(new Titul(2L, "NINE INCH NAILS - BROKEN", new BigDecimal("1200")));
            titulRepository.save(new Titul(3L, "NINE INCH NAILS - THE DOWNWARD SPIRAL", new BigDecimal("1300")));
        }
    }
}