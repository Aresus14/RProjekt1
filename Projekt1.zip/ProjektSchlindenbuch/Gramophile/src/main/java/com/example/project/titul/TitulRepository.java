package com.example.project.titul;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TitulRepository extends JpaRepository<Titul, Long>{
}
