package com.example.project.titul;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TitulService {

    @Autowired
    private TitulRepository titulRepository;

    public Titul findById(Long id) {
        return titulRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Titul nenalezen"));
    }
}