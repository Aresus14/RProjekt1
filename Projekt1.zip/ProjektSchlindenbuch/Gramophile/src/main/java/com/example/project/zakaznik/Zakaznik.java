package com.example.project.zakaznik;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;


@Entity
@Table(name = "ZAKAZNIK")
public class Zakaznik {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_zakaznik")
    private Long idZakaznik;

    @Size(max = 50)
    @Column(name = "jmeno", length = 50, nullable = false)
    private String jmeno;

    @Size(max = 20)
    @Column(name = "telefon", length = 20, nullable = false)
    private String telefon;

    @Size(max = 50)
    @Email
    @Column(name = "email", length = 50)
    private String email;


    public Zakaznik() {}

    public Zakaznik(Long idZakaznik, String jmeno, String telefon, String email) {
        this.idZakaznik = idZakaznik;
        this.jmeno = jmeno;
        this.telefon = telefon;
        this.email = email;
    }

    public Long getIdZakaznik() {return idZakaznik;}
    public void setIdZakaznik(Long idZakaznik) {this.idZakaznik = idZakaznik;}
    public String getJmeno() {return jmeno;}
    public void setJmeno(String jmeno) {this.jmeno = jmeno;}
    public String getTelefon() {return telefon;}
    public void setTelefon(String telefon) {this.telefon = telefon;}
    public String getEmail() {return email;}
    public void setEmail(String email) {this.email = email;}
}