package com.example.project.zakaznik;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ZakaznikRepository extends JpaRepository<Zakaznik, Long> {

}