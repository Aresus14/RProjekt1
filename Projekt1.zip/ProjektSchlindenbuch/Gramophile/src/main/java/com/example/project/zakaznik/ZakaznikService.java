package com.example.project.zakaznik;

import com.example.project.adresa.AdresaRepository;
import com.example.project.objednavka.ObjednavkaService;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class ZakaznikService {

}
