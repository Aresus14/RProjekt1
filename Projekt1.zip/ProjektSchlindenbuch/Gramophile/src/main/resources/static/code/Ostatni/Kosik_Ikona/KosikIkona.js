const buyButton = document.querySelector('.popup-button1');
const cartCount = document.getElementById('cart-count');

let count = parseInt(localStorage.getItem('cartCount')) || 0;
cartCount.textContent = count;

buyButton.addEventListener('click', () => {
    count++;

    if (count > 20) {
        count = 0; // vynuluj po dosažení 20
    }

    cartCount.textContent = count;
    localStorage.setItem('cartCount', count); // uložíme stav
});
