let vybranyProdukt = "";

function otevritModal(nazevProduktu) {
    vybranyProdukt = nazevProduktu;
    document.getElementById("modal-text").innerText =
        `Chcete opravdu přidat "${nazevProduktu}" do košíku?`;
    document.getElementById("modal").style.display = "flex";
}

function zavritModal() {
    document.getElementById("modal").style.display = "none";
    vybranyProdukt = "";
}

function potvrdit() {
    zobrazNotifikaci("Produkt byl přidán do košíku.");
    zavritModal();
}

// 👇 Přidaná funkce pro hlášku
function zobrazNotifikaci(zprava) {
    const notifikace = document.getElementById("notifikace");
    notifikace.innerText = zprava;
    notifikace.style.display = "block";

    setTimeout(() => {
        notifikace.style.display = "none";
    }, 2500); // zmizí po 2,5 sekundách
}